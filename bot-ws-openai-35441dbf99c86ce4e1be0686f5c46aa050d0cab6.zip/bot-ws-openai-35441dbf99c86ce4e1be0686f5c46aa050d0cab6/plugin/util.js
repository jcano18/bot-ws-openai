const cleanText = (inputText) => {
    return inputText
}

module.exports = { cleanText }
